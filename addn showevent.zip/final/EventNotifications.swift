import Foundation

extension Notification.Name{
    static let addFromAddEventScreen = Notification.Name("addFromAddEventScreen")
    static let editFromEditScreen = Notification.Name("editFromEditScreen")
    static let deleteFromDeleteScreen = Notification.Name("deleteFromDeleteScreen")
}
