import Foundation
class Configs{
    static let placeIdentifier = "placeIdentifier"
    static let searchTableViewID = "searchTableViewID"
}
